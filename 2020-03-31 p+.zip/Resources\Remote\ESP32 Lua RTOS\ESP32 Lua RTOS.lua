
--**************************************************************************$
--* Copyright (C) 2013-2018 Ing. Buero Riesberg - All Rights Reserved
--* Unauthorized copy, print, modify or use of this file, via any medium is
--* strictly prohibited. Proprietary and confidential.
--* Written by Andre Riesberg <andre@riesberg-net.de>
--***************************************************************************/

-- 06.03.2019 12:58:59 AR V1.0a
-- 18.03.2019 10:58:50 AR V1.0b Timer fixed
-- 28.03.2019 10:57:15 AR V1.0c Too many open files. Add missing f:close
-- 22.08.2019 07:53:21 AR V1.0d Some modifications
-- 25.02.2020 10:46:21 AR V1.0e Optinal debug

--local debug = sys.debug
--local debug = print
local debug = function(...) end

-- Special hash function.
-- Line endings can be different between windows and ESP32, so ignore CR and LF.
-- ESP32 Lua RTOS don't use int64, so mask out the lower 32 bist
function calcHash(name)
  f = io.open(name, 'r')
  if f then
    local h = 37
    while true do
      local c = f:read(1)
      if not c then
        f:close()
        return h
      end
      local b = c:byte(1)
      if b ~= 10 and b ~= 13 then
        h = ((h * 54059) ~ (b * 76963)) & 0x7FFFFFFF
      end
    end
  end
  return -1
end

target = {
  name = 'ESP32 Lua RTOS',
  lua = 5.3,

  parameter = {
    startUpload = true,
    startPowerup = false,
    com = 4,
    baud = 115200,
  },

  init = function(self)
  end,

  open = function(self)
    gui.needPPVersion(2, 4, 'a')
    gui.add('HTMLInfo', 'Info', self.name, [[
<b>ESP32 running Lua RTOS</b><br><br>
For more informations visit <a href="https://github.com/whitecatboard/Lua-RTOS-ESP32">Lua-RTOS-ESP32</a>
]], {Height = 100})
    gui.add('EditCOM', 'EditCOM', 'COM port number')
    gui.add('Edit', 'EditBaud', 'Baud rate', {IntegerMode = true})
    gui.add('CheckBox', 'CheckBoxStartUpload', 'Start model after upload\n  (call startup.lua)', {Width = 250, Height = 40})
    gui.add('CheckBox', 'CheckBoxStartPowerup', 'Start model on power up \n  (modify file autorun.lua with "dofile(\'startup.lua\')")', {Width = 250, Height = 40})
    gui.set('EditCOM', 'Integer', self.parameter.com)
    gui.set('EditBaud', 'Integer', self.parameter.baud)
    gui.set('CheckBoxStartUpload', 'Checked', self.parameter.startUpload)
    gui.set('CheckBoxStartPowerup', 'Checked', self.parameter.startPowerup)
  end,

  apply = function(self)
    self.parameter.com = gui.get('EditCOM', 'Integer')
    self.parameter.baud = gui.get('EditBaud', 'Integer')
    self.parameter.startUpload = gui.get('CheckBoxStartUpload', 'Checked')
    self.parameter.startPowerup = gui.get('CheckBoxStartPowerup', 'Checked')
  end,

  close = function(self)
  end,

  generate = function(self, what)
     if what == 'GENERATOR_MAIN' then
       return [[
do
  print('Start p+ simulation ' .. (sim.stepRateS * 1000) .. 'ms cycle time')
  block.start()
  collectgarbage()
  print('Start finished, enter main simulation loop. ' .. collectgarbage('count'))
  local trigger = 0
  --local trigger = event.create()
  local t = tmr.attach(
    tmr.TMR0,
    math.floor(sim.stepRateS * 1000000),
    function()
      trigger = trigger + 1
      --trigger:broadcast()
    end
  )
  t:start()
  while true do
    while trigger == 0 do
      tmr.delayms(1)
    end
    if trigger > 1 then
      print('Overrun ', trigger)
    end
    trigger = 0
    --trigger:wait()
    if sim.cycle then
      sim.cycle(true)
    end
    block.step()
    collectgarbage()
    sim.step = sim.step + 1
    sim.stepT0 = sim.stepT0 + 1
    sim.timeS = sim.timeS + sim.stepRateS
    if sim.cycle then
      sim.cycle(false)
    end
    if sim.step % 10 == 0 then
      print('{M' .. collectgarbage('count') .. '}')
    end
  end
end
     ]], true
    end
  end,

  inject = function(self, files)
    local sys = require 'sys'
    local token = require 'token'
    local serial = require 'serial'

    debug('Injector start')

    injector.needPPVersion(2, 2, 'e')
    injector.assert(
      injector.projectHasFlags('RunInRealtime', 'Endless', 'SaveMemory'),
      "Injector needs project options 'RunInRealtime', 'Endless' and 'SaveMemory'"
    )

    injector.closeLuaConsole('ESP32 board COM' .. self.parameter.com);

    local esp = serial.new(self.parameter.com)
    esp:open(self.parameter.baud, 8, 'N', 1)

    -- Send a string followed by cr lf
    -- Read in all line until prompt ('/ > ') is detected
    local function s(s)
      if s then
        debug('>' .. s)
        esp:send(s .. '\r\n')
      end
      local results = {}
      for i = 1, 10000 do
        local recv = esp:recv('\r\n')
        sys.sleep(0.001)
        if recv then
          results[#results + 1] = recv
          debug('<' .. recv)
          if recv == '/ > ' then
            return results
          end
        end
      end
      injector.assert(false, 'Receive timeout')
    end

    do
      local function p(s)
        debug('>>' .. s)
        return s
      end
      local l = injector.addLabel('<b>Send ctrl-c to board</b>')
      p(esp:recv())
      for i = 1, 3 do
        esp:send(string.char(3))
        sys.sleep(0.5)
      end
      injector.appendLabel(l, ' Fetching console output ')
      repeat
        sys.sleep(0.2)
        injector.appendLabel(l, '.')
      until p(esp:recv())
      injector.appendLabel(l, ' Done')
    end

    for i = 1, #files do
      local f, message = io.open(files[i].host, 'rb')
      injector.assert(f, 'Can\'t open ' .. files[i].host .. ' ' .. (message or ''))
      injector.assert(f:read(1) ~= 27, 'Injector don\'t support precompiled files')
      f:close()
    end

    -- Count the total number of lines
    -- and the size of all files
    local lineCounts = {}
    local fileSizes = {}
    local lineCountTotal = 0
    for i = 1, #files do
      local lineCount, fileSize = 0, 0
      for line in io.lines(files[i].host) do
        lineCount = lineCount + 1
        fileSize = fileSize + line:len() + 1
      end
      lineCounts[files[i].remote] = lineCount
      fileSizes[files[i].remote] = fileSize
      lineCountTotal = lineCountTotal + lineCount
    end

    local pb = injector.addProgressBar('Upload progress', lineCountTotal, false)
    local fl = injector.addFileList('Files')

    local dirs = {}
    local lineCount = 0
    for i = 1, #files do
      local hash1 = calcHash(files[i].host)
      local dir = string.match('/' .. files[i].remote, '^(/.+/)')
      if dir and not dirs[dir] then
        injector.log('Make dir', dir)


        print('*********Make dir', dir)




        local dir2 = ''
        for token in dir:gmatch('/?([^/]*)/') do
          dir2 = dir2 .. '/' .. token
          injector.log(dir2)

          print(dir2)

          s("os.mkdir('" .. dir2 .. "')")
        end
        dirs[dir] = true
      end
      --s("os.remove('" .. files[i].remote .. "')")

      injector.log('hash[', files[i].remote)
      local results = s([[f=io.open('/]] .. files[i].remote .. [[','r') if f then local h=37 while true do local c=f:read(1) if not c then print(h) break end local b=c:byte(1) if b~=10 and b~=13 then h=((h*54059)~(b*76963))&0x7FFFFFFF end end end]])
      for i = 1, #results do
        injector.log(i, results[i])
      end
      injector.log(']')
      local hash2 = tonumber(results[2])
      if hash1 ~= hash2 then
        injector.addFile(fl, files[i].remote, 'Upload ' .. lineCounts[files[i].remote] .. ' lines')
        injector.log('Different test', files[i].remote, 'here', hash1, 'there', hash2)
        sys.sleep(0.1)
        s("collectgarbage(); f = io.open('/" .. files[i].remote .. "','w+')")
        for line in io.lines(files[i].host) do
          s("collectgarbage() f:write(" .. injector.wrapString(line) .. "..string.char(10))")
          lineCount = lineCount + 1
          injector.setProgressBar(pb, lineCount)
          sys.sleep(0.1)
        end
        s("f:close()")
        s("collectgarbage()")
        s([[f=io.open('/]] .. files[i].remote .. [[','r')]])
        local results = s([[if f then local h=37 while true do local c=f:read(1) if not c then print(h) break end local b=c:byte(1) if b~=10 and b~=13 then h=((h*54059)~(b*76963))&0x7FFFFFFF end end end]])
        local hash3 = tonumber(results[2])
        if hash1 ~= hash3 then
          injector.log('Different verify', files[i].remote, 'here', hash1, 'there', hash3)
          injector.assert(hash1 == hash3, 'File verify fail ' .. files[i].remote)
        end
        s("f:close()")
      else
        injector.addFile(fl, files[i].remote, '<b>Up to date</b>')
        injector.log('Equal', files[i].remote)
        lineCount = lineCount + lineCounts[files[i].remote]
        injector.setProgressBar(pb, lineCount)
      end
    end
    injector.setProgressBar(pb, lineCountTotal)

    --if self.parameter.startPowerup then
    --  injector.addLabel('<b>Writring <i>autorun.lua</i> to start on power up and reboot board</b>')
    --  s("f = io.open('/autorun.lua','w+') f:write([[dofile('startup.lua')]]) f:close()")
    --  esp:send('os.exit(true, true)\r\n')
    --end
    --if self.parameter.startUpload then
    --  injector.addLabel('<b>Executing <i>startup.lua</i></b>')
    --  esp:send('\r\nstartup.lua\r\n')
    --end

    --esp:send('\r')
    esp:close()

    injector.addLabel('<FONT size="10"><FONT color="#000080"><b>Redirect boards output (COM' .. self.parameter.com .. ') to console.</b></FONT></FONT>')
    do
      source = [[
local sys = require 'sys'
local token = require 'token'
local serial = require 'serial'
local esp = serial.new(COM)
esp:open(BAUD, 8, 'N', 1)
do
  local first = true
  while true do
    local recv = esp:recv('\r\n')
    if recv then
      print(recv)
    else
      sys.sleep(0.01)
      if first then
        sys.sleep(0.3)
        esp:send('\n\r\n\r')
        first = false
      end
      local send = token.get('.console.send', '')
      if send and send:len() > 0 then
        esp:send(send)
      end
    end
  end
end
]]
      local replaces = {
        ['BAUD'] = self.parameter.baud,
        ['COM'] = self.parameter.com,
      }
      source = source:gsub('%a+', replaces)
      injector.spanLuaConsole('ESP32 board COM' .. self.parameter.com, source, 'GreenYellow', 'Black');
    end

  end,
}



--[[
return [[
do
  block.start()

  local co = coroutine.create(
    function()
      while true do
        coroutine.yield()
        if sim.cycle then
          sim.cycle(true)
        end
        block.step()
        collectgarbage()
        sim.step = sim.step + 1
        sim.stepT0 = sim.stepT0 + 1
        sim.timeS = sim.timeS + sim.stepRateS
        if sim.cycle then
          sim.cycle(false)
        end
      end
    end
  )
  print('Start p+ simulation ' .. (sim.stepRateS * 1000) .. 'ms cycle time')
  local t = tmr.attach(
    tmr.TMR0,
    math.floor(sim.stepRateS * 1000000),
    function()
      if coroutine.status(co) == 'suspended' then
        coroutine.resume(co)
      end
    end
  )
  t:start()
  while true do tmr.sleep(1) end
end
    ]], true
--]]
