--[[
 *  p+ Lua library
 *  Copyright (C) Andre Riesberg
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, 
 *  write to the Free Software Foundation, Inc., 
 *  51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
--]]

local avatarBase = {}

local aw, al = 0.4, 8.0 -- Arrow w and length

avatarBase.calcBoxY = function(h, n, i)
  return h / 2.0 / n * (i * 2 - 1)
end
avatarBase.calcBoxX = function(w, n, i)
  return w / 2.0 / n * (i * 2 - 1)
end

-- Calc a pin line
-- parameter
--   w, h size of the symbol (mostly the rectangle)
--   n, i number of pin and the number of the pin (base 1=
--   len  the pin length
-- return 
--   x1, y1 the cnnection side of a pin line
--   x2, y2 the other side of the pin (mostly at the symbol rectangle)

local calcBoxXYFunctions = {
  [0] = function(w, h, n, i, len)
    local y = avatarBase.calcBoxY(h, n, i)
    return w + len, y, w, y
  end,
  [90] = function(w, h, n, i, len)
    local x = avatarBase.calcBoxX(w, n, i)
    return x, h + len, x, h
  end,
  [180] = function(w, h, n, i, len)
    local y = avatarBase.calcBoxY(h, n, i)
    return -len, y, 0, y
  end,
  [270] = function(w, h, n, i, len)
    local x = avatarBase.calcBoxX(w, n, i)
    return x, -len, x, 0
  end
}

-- Default pin name draw function
-- Pin name is placed inside the symbol rectangel at x2, y2
-- For non NSEW pins it is placed centerd at x2, y2

avatarBase.drawPinName = function(pin, dir)
  if dir == 0 then
    draw.text(pin.x2 - 7, pin.y2, 0, 0, pin.name, 5)
  elseif dir == 90 then
    draw.text(pin.x2, pin.y2 - 7, 0, 0, pin.name, 7)
  elseif dir == 180 then
    draw.text(pin.x2 + 7, pin.y2, 0, 0, pin.name, 3)
  elseif dir == 270 then
    draw.text(pin.x2, pin.y2 + 7, 0, 0, pin.name, 1)
  else
    draw.text(pin.x2, pin.y2, 0, 0, pin.name, 4)
  end
end

-- Default pin signal or default value draw function
-- Pin name is placed outside the symbol rectangel at x2, y2 move up or right
-- For non NSEW pins it is placed centerd at x2, y2

avatarBase.drawPinSignal = function(pin, dir)
  if dir == 0 then
    draw.text(pin.x2 + 5, pin.y2 - 2, 0, 0, pin.signal or pin.default, 6)
  elseif dir == 90 then
    draw.text(pin.x2 + 2, pin.y2 + 5, 0, 0, pin.signal or pin.default, 0)
  elseif dir == 180 then
    draw.text(pin.x2 - 5, pin.y2 - 2, 0, 0, pin.signal or pin.default, 8)
  elseif dir == 270 then
    draw.text(pin.x2 + 2, pin.y2 - 5, 0, 0, pin.signal or pin.default, 6)
  else
    draw.text(pin.x2, pin.y2, 0, 0, pin.signal or pin.default, 4)
  end
end

-- Default input pin draw function
-- A simple black line with an input arrow

avatarBase.drawLineInputPin = function(pin, dir)
  draw.line(pin.x1, pin.y1, pin.x2, pin.y2)
  local w = dir / 180.0 * math.pi
  local xz, yz = (pin.x2 + pin.x1) / 2.0, (pin.y2 + pin.y1) / 2.0
  draw.line(xz, yz, xz + al * math.cos(w + aw), yz + al * math.sin(w + aw)) 
  draw.line(xz, yz, xz + al * math.cos(w - aw), yz + al * math.sin(w - aw)) 
end
    
-- Default output pin draw function
-- A simple black line with an ouput arrow
    
avatarBase.drawLineOutputPin = function(pin, dir)
  draw.line(pin.x1, pin.y1, pin.x2, pin.y2) 
  local w = dir / 180.0 * math.pi
  local xz, yz = (pin.x2 + pin.x1) / 2.0, (pin.y2 + pin.y1) / 2.0
  draw.line(xz, yz, xz - al * math.cos(w + aw), yz - al * math.sin(w + aw)) 
  draw.line(xz, yz, xz - al * math.cos(w - aw), yz - al * math.sin(w - aw)) 
end

-- Actual theme

local theme = false

-- List of all themes

local themes = {
  
  -- Default theme: Black lines 
  [false] = {
    defaults = {
      fill = {
        color = 0xFFFFFF, 
      },
      line = {
        color = 0x000000, 
      },
      pin = {
        len = 20,
        name = {
          color = 0x000000, 
        },
        signal = {
          color = 0x000000,
        },
      }
    },
    drawInputPin = avatarBase.drawLineInputPin,
    drawOutputPin = avatarBase.drawLineOutputPin,
    drawPinName = avatarBase.drawPinName,
    drawPinSignal = avatarBase.drawPinSignal,
  },
  
  -- State machine theme
  ['statemachine'] = {
    defaults = {
      fill = {
        color = 0xFFF0C0, 
      },
      line = {
        color = 0x000000, 
      },
      pin = {
        len = 20,
        name = {
          color = 0x000000, 
        },
        signal = {
          color = 0x000000,
        },
      }
    },
    drawInputPin = function(pin, dir)
      if not pin.class then
        avatarBase.drawLineInputPin(pin, dir)
      else
        draw.polygon(pin.x1, pin.y1, pin.x1 - 4, pin.y1 - 4, pin.x1 + 4, pin.y1 - 4) 
      end
    end,
    drawOutputPin = function(pin, dir)
      if not pin.class then
        avatarBase.drawLineOutputPin(pin, dir)
      else
        draw.polygon(pin.x1, pin.y1, pin.x1 - 4, pin.y1 - 4, pin.x1 + 4, pin.y1 - 4) 
      end
    end,
    drawPinName = avatarBase.drawPinName,
    drawPinSignal = avatarBase.drawPinSignal,
  },
  
  -- Smarty theme: Pins are red or blue dots
  ['smarty'] = {
    defaults = {
      fill = {
        color = 0xE0E0E0, 
      },
      line = {
        color = 0x606060, 
      },
      pin = {
        len = 0,
        name = {
          color = 0x000000, 
        },
        signal = {
          color = 0x000000,
        },
      }
    },
    drawInputPin = function(pin)
      local colors = {
        [false] = 0x00B2FF,
        ['pin'] = 0x000000,
      }
      draw.setColorA(colors[pin.tag or false])
      draw.disk(pin.x1, pin.y1, 5)
    end,
    drawOutputPin = function(pin)
      local colors = {
        [false] = 0x00B2FF,
        ['pin'] = 0x000000,
        ['yes'] = 0x70D030,
        ['no'] = 0xFF4000,
      }
      draw.setColorA(colors[pin.tag or false])
      draw.disk(pin.x1, pin.y1, 5)
    end,
    drawPinName = avatarBase.drawPinName,
    drawPinSignal = avatarBase.drawPinSignal,
  },
  
}

-----------------------------------------------------------------------------
-- Public functions using the current theme
-----------------------------------------------------------------------------

avatarBase.calcPinsXY = function(w, h, inputs, outputs)
  -- Make 'pins by dir' list 
  local pinsByDir = {}
  for i = 1, #inputs do
    local pin = inputs[i]
    local dir = pin.dir or 180
    if not pinsByDir[dir] then
      pinsByDir[dir] = {}
    end
    local pinsByDirList = pinsByDir[dir]
    pinsByDirList[#pinsByDirList + 1] = pin
  end
  for i = 1, #outputs do
    local pin = outputs[i]
    local dir = pin.dir or 0
    if not pinsByDir[dir] then
      pinsByDir[dir] = {}
    end
    local pinsByDirList = pinsByDir[dir]
    pinsByDirList[#pinsByDirList + 1] = pin
  end
  -- calc x, y 
  for dir = 0, 270, 90 do
    local pinsByDirList = pinsByDir[dir]
    if pinsByDirList then
      for i = 1, #pinsByDirList do
        if calcBoxXYFunctions[dir] then
          local xr1, yr1, xr2, yr2 = calcBoxXYFunctions[dir](w, h, #pinsByDirList, i, pinsByDirList[i].len or themes[theme].defaults.pin.len)  --  or
          pinsByDirList[i].x1, pinsByDirList[i].y1 = xr1, yr1
          pinsByDirList[i].x2, pinsByDirList[i].y2 = xr2, yr2
        end
        --print(pinsByDirList[i].name, pinsByDirList[i].x, pinsByDirList[i].y)
      end
    end
  end

end  

avatarBase.drawInputPin = function(pin)
  themes[theme].drawInputPin(pin, pin.dir or 180)
end

avatarBase.drawOutputPin = function(pin)
  themes[theme].drawOutputPin(pin, pin.dir or 0)
end

avatarBase.drawInputPinName = function(pin)
  themes[theme].drawPinName(pin, pin.dir or 180)
end

avatarBase.drawOutputPinName = function(pin)
  themes[theme].drawPinName(pin, pin.dir or 0)
end
  
avatarBase.drawInputPinSignal = function(pin)
  themes[theme].drawPinSignal(pin, pin.dir or 180)
end

avatarBase.drawOutputPinSignal = function(pin)
  themes[theme].drawPinSignal(pin, pin.dir or 0)
end
 
avatarBase.defaults = function()
  return themes[theme].defaults
end

avatarBase.setTheme = function(_theme)  
  theme = _theme
end
  
return avatarBase












