--[[
 *  P+ Lua library
 *  Copyright (C) Andre Riesberg
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, 
 *  write to the Free Software Foundation, Inc., 
 *  51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
--]]

-----------------------------------------------------------------------------
-- Sun position calculation
-- 04.01.2014 AR First version
-- 14.09.2015 AR Minor modifications, move to Lua 5.3 (atan2 -> atan)
-----------------------------------------------------------------------------

math = require 'math'

local sun = {}

sun.deg2Rad = function(x)
  return x * (math.pi / 180.0)
end

sun.rad2Deg = function(x)
  return x * (180.0 / math.pi)
end

-----------------------------------------------------------------------------
-- Calculate days since year 2000 with fractional part
-----------------------------------------------------------------------------

sun.daysSince2000 = function(year, month, day, houre, minute, second)
  day = math.floor(day)
  month = math.floor(month)
  year = math.floor(year)
  houre = math.floor(houre)
  minute = math.floor(minute)
  second = math.floor(second)
  return
    367 * year - 730531.5 -
    math.floor(7 * (year + math.floor((month + 9) / 12.0)) / 4.0) +
    math.floor(275 * month / 9.0) +
    day +
    (houre + minute / 60.0 + second / 3600.0) / 24.0
end

-----------------------------------------------------------------------------
-- Calculate sun position
-- longitudeDeg is the E/W position, W is plus, E is minus
-- latitudeDeg is the N/S position, N is plus, S is minus
-- altitudeDeg is the hight of the sun. 0.0 at horizon 90.0 is nadir
-- azimutDeg is the horizontal position. 180 is S, < 180 is SO, > 180 is SO
-- houreAngleDeg is the angle of the virtual sun circle.
--   At 12:00 it is 0.0, at 24:00 it is 180.0
-----------------------------------------------------------------------------

sun.position = function(daysSince2000, longitudeDeg, latitudeDeg)

  -- Prevent floting point errors
  if latitudeDeg < -89.999 then
    latitudeDeg = -89.999
  elseif latitudeDeg > 89.999 then
    latitudeDeg = 89.999
  end

  local latitudeRad = sun.deg2Rad(latitudeDeg)

  local lstDeg = math.fmod(280.46061837 + 360.98564736629 * daysSince2000 + longitudeDeg, 360.0)
  local lstRad = sun.deg2Rad(lstDeg)

  local century = daysSince2000 / 36525.0

  local sunMeanLongitudeDeg = math.fmod(280.461 + 0.9856474 * daysSince2000, 360.0)

  local sunMeanAnomalyDeg = math.fmod(357.528 + 0.9856003 * daysSince2000, 360.0)
  local sunMeanAnomalyRad = sun.deg2Rad(sunMeanAnomalyDeg)

  local sunLongitudeDeg = sunMeanLongitudeDeg + 1.915 * math.sin(sunMeanAnomalyRad) + 0.02 * math.sin(2.0 * sunMeanAnomalyRad)
  local sunLongitudeRad = sun.deg2Rad(sunLongitudeDeg)

  local sunObliquityOfEclipticDeg = (84381.448 - 46.815 * century) / 3600.0
  local sunObliquityOfEclipticRad = sun.deg2Rad(sunObliquityOfEclipticDeg)

  local sunAlphaRad = math.atan(math.sin(sunLongitudeRad) * math.cos(sunObliquityOfEclipticRad) - math.tan(0.0) * math.sin(sunObliquityOfEclipticRad), math.cos(sunLongitudeRad))

  local sunDeltaRad = math.asin(math.sin(0.0) * math.cos(sunObliquityOfEclipticRad) + math.cos(0.0) * math.sin(sunObliquityOfEclipticRad) * math.sin(sunLongitudeRad))

  local sunHoureAngleRad = math.fmod(lstRad - sunAlphaRad, 2.0 * math.pi)

  local houreAngleDeg = sun.rad2Deg(sunHoureAngleRad)

  local sunHoureAngleSin = math.sin(sunHoureAngleRad)
  local sunHoureAngleCos = math.cos(sunHoureAngleRad)

  local sunDeclinationSin = math.sin(sunDeltaRad)
  local sunDeclinationCos = math.cos(sunDeltaRad)

  local latitudeSin = math.sin(latitudeRad)
  local latitudeCos = math.cos(latitudeRad)

  local sunAltitudeSin = sunDeclinationSin * latitudeSin + sunDeclinationCos * latitudeCos * sunHoureAngleCos

  local sunAltitudeRad = math.asin(sunAltitudeSin)
  local altitudeDeg = sun.rad2Deg(sunAltitudeRad)

  local sunAltitudeCos = math.cos(sunAltitudeRad)

  local sunAzimutCos = ((sunDeclinationSin - latitudeSin * sunAltitudeSin) / (latitudeCos * sunAltitudeCos))
  local sunAzimutRad = math.acos(sunAzimutCos)

  if sunHoureAngleSin < 0.0 then
    azimutDeg = sun.rad2Deg(sunAzimutRad)
  else
    azimutDeg = sun.rad2Deg(2.0 * math.pi - sunAzimutRad)
  end

  return altitudeDeg, azimutDeg, houreAngleDeg
end

-----------------------------------------------------------------------------
return sun
-----------------------------------------------------------------------------
