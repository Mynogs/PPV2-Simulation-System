
--**************************************************************************$
--* Copyright (C) 2013-2018 Ing. Buero Riesberg - All Rights Reserved
--* Unauthorized copy, print, modify or use of this file, via any medium is
--* strictly prohibited. Proprietary and confidential.
--* Written by Andre Riesberg <andre@riesberg-net.de>
--***************************************************************************/

-- 18.04.2018 09:30:18 AR V1.0a

target = {
  name = 'CN1',

  parameter = {
    ip = '',
    port = 11111,
  },

  init = function(self)
  end,

  open = function(self)
    gui.add('HTMLInfo', 'Info', self.name, [[
<b>CN1 with firmware >= <u>V3.0d</u></b><br><br>
This injector generates a FAT32 disk image containing all files for the model.<br>
The disk image is loaded from the CN1 via TFTP protocol to the internal FLASH memory.<br><br>
To automatic restart the CN1 board:
<ul>
<li>Add the <i>Backdoor</i> block to your model and upload the model. You must see a message 'Backdoor open'<br>
<li>Set the correct IP address of the CN1 board below
</ul>
]], {Height = 150})
    gui.add('EditIP', 'EditIP', 'IP', 'CN*')
    gui.add('Edit', 'EditPort', 'Port', {Width = 60})
    gui.set('EditIP', 'Text', self.parameter.ip)
    gui.set('EditPort', 'Text', self.parameter.port)
  end,

  apply = function(self)
    self.parameter.ip = gui.get('EditIP', 'Text')
    self.parameter.port = gui.get('EditPort', 'Text')
  end,

  close = function(self)
  end,

  generate = function(self, what)
    if what == 'GENERATOR_REQUIRE' then
      return [[
sys = require 'sys'
pin = require 'pin'
w5500 = require 'w5500'
token = {set = function() end, get = function() end}
      ]]
    end
    if what == 'GENERATOR_MAIN' then
      return [[
do
  local pin = require 'pin'
  --pin.config('A7', 'LOW')
  while true do
    local tick, ellapsedS = sys.isTicked()
    if tick then
      sim.timeS = sim.timeS + ellapsedS
      if not nextS then
        nextS = sim.timeS
      end
      if sim.timeS >= nextS then
        --pin.set('A7', true)
        block.step()
        collectgarbage()
        --pin.set('A7', false)
        sim.step = sim.step + 1
        sim.stepT0 = sim.stepT0 + 1
        nextS = nextS + sim.stepRateS
      end
    end
    w5500.serve()
  end
end
      ]]
    end
  end,

  inject = function(self, files, xml, hostDir)
    local sys = require 'sys'
    local socket = require 'socket'
    local token = require 'token'

    local manualReset = true
    if self.parameter.ip:len() > 7 then
      local udp = socket.udp()
      if udp then
        injector.addLabel('Send restart command to backdoor at ' .. self.parameter.ip .. ':' .. self.parameter.port)
        udp:settimeout(1)
        udp:sendto('sys.restart()', self.parameter.ip, self.parameter.port)
        --local recv = udp:receive()
        --print('##', recv)
        udp:close()
      end
    end

    local image = injector.newFatFs(1024)
    image:buildFromDirectory(hostDir)
    --image:crunch()
    --image:schowDirectory('0:')

    local tftp = injector.newTFTPServer()
    setmetatable(
      tftp,
      {
        __gc = function()
          tftp:close()
        end
      }
    )

    tftp:addFileContent('FlashDisk.fat', image:get())
    if manualReset then
      injector.addLabel('<FONT size="10"><FONT color="#000080"><b>If nothing happends press reset on the CN1 board to start upload process</b></FONT></FONT>')
    end
    local label = injector.addLabel('TFTP status')
    local pb = injector.addProgressBar('Upload', 100, true)

    do
      tftp:open()
      local status, info, progress
      while true do
        status, info, progress = tftp:status()
        --print(status)
        injector.setLabel(label, '<b>' .. info .. '</b> ')
        if status == 'transfer' then
          injector.setProgressBar(pb, progress)
        elseif status == 'finish' or status == 'fail' then
          break
        end
        sys.sleep(0.05)
      end
      if status == 'finish' then
        injector.addLabel('<FONT color="#008000"><b>Succesful</b></font>')
      else
        injector.addLabel('<FONT color="#800000"><b>Fail!</b></font>')
      end
    end

    injector.delayedClose()
  end,
}









