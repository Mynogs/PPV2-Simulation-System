-- console.lua AR

print('Loading console.lua')
vector = require 'vector'
matrix = require 'matrix'
complex = require 'complex'
