-- Code snipped submenu
-- AR

local menu = {
  ['Templates'] = {
[=[
Generic sceleton
-- V1.0a

--block.setSize(51, 51)

generic = {
  parameter = {
    inputs = 1
  },

  init = function(self)
  end,

  open = function(self)
  end,

  apply = function(self)
  end,

  close = function()
  end,

  avatar = function(self)
    return block.getDefaultAvatar(0x00)
  end,

  generate = function(self)
    local source =
      [==[
        local block = {}

        block.start = function()
        end

        block.step = function()
          return
        end

        block.stop = function()
        end

        return block
      ]==]
    local replaces = {
    }
    return string.gsub(source, '%a+', replaces)
  end,
}
]=]
  },
  ['Replaces'] = {
    "['X'] = table.concat(block.getInputsPinNames(), ', '),",
    "['X'] = table.concat(block.getOutputsPinNames(), ', '),",
  },
  ['Block flags'] = {
    'block.modifyFlags(\'CanPlaceToDiagram\', false)',
    'block.modifyFlags(\'CanGenerateCode\', false)',
    'block.modifyFlags(\'CanStopSimulation\', true)',
    'block.modifyFlags(\'IsSubSystem\', true)',
    'block.modifyFlags(\'HasSubSampleOutput\', true)',
    'block.modifyFlags(\'BreakAlgebraLoop\', true)',
    'block.modifyFlags(\'IsEnabledSubSystem\', true)',
    'block.modifyFlags(\'SupressStartFunctionCall\', true)',
    'block.modifyFlags(\'SupressStopFunctionCall\', true)',
    'block.modifyFlags(\'MouseReactiv\', true)',
    'block.modifyFlags(\'Realtime\', true)',
    'block.modifyFlags(\'AutoAddInputPin\', true)',
    'block.modifyFlags(\'AutoAddOutputPin\', true)',
    'block.modifyFlags(\'SampleRateGate\', true)',
    'block.modifyFlags(\'Protected\', true)',
    'block.modifyFlags(\'TabbedGUI\', true)',
  },
  ['Block config functions'] = {
    'block.getName()',
    'block.getClassName()',
    'block.getUniqueName()',
    'block.getUUID()',
    'block.getAvatarInfo()', 
    'block.getInputsPinCount()', 
    'block.getOutputsPinCount()', 
    'block.getIntputsPinsNames(i1,i2)',
    'block.getOutputsPinsNames(i1,i2)',
    'block.setInputPinAppearance(i, length)',
    'block.setOutputPinAppearance(i, length)',
    'block.getDefaultAvatar(type,textSource,source)', 
    'block.setInputsPinCount(n)',
    'block.setInputPinName(i,s)',
    'block.setInputPinTypeRestrains(i{,s})',
    'block.setInputPinDefault(i,s)',
    'block.setOutputsPinCount(n)',
    'block.setOutputPinName(i,s)',
    'block.setOutputPinTypeRestrains(i{,s})',
    'block.setRate(rateDivider)',
    'block.modifyFlags(flag,true)',
    'block.findBlocksGlobal(classname)',
    'block.call(uuid,function[,S])',
    'block.wrapString(S[,level])',
    function() return 'block.needPPVersion(' .. require('token').get('.version') .. ')' end,
  },
  ['Commends'] = {
    function() return '-- ' .. os.date('%d.%m.%Y %X') .. ' AR V1.0a' end,
    function() return '-- ' .. os.date('%d.%m.%Y %X') .. ' AR V1.0b' end,
    function() return '-- ' .. os.date('%d.%m.%Y %X') .. ' AR V1.0c' end,
  },
  ['Misc'] = {
    'block.setSize(51, 51)',
    'block.setSize(151, 26)',
    'block.setSize(151, 51)',
  },
}

return menu
