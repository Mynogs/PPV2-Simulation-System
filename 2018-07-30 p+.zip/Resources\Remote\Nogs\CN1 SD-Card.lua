
--**************************************************************************$
--* Copyright (C) 2013-2018 Ing. Buero Riesberg - All Rights Reserved
--* Unauthorized copy, print, modify or use of this file, via any medium is
--* strictly prohibited. Proprietary and confidential.
--* Written by Andre Riesberg <andre@riesberg-net.de>
--***************************************************************************/

-- 06.05.2017 05:56:36 AR V1.0a
-- 30.01.2018 06:29:47 AR V1.0b Sleep a little time between the transfer of the files
-- 17.20.2018 11:59:25 AR V1.0c Don't upload unchanged files (using file content hashing)

target = {
  name = 'CN1',

  parameter = {
    ip = '169.254.112.239',
    port = 8172,
  },

  init = function(self)
  end,

  open = function(self)
    gui.add('HTMLInfo', 'Info', self.name, [[
<b>CN1 with firmware >= <u>2.0</u> using Zerobranes mobdebug</b><br><br>
To activate mobdebug on the CN1 board put a file with the name 'config.lua' in the root director of a micro sd-card.<br>
In the file enter the text 'moddebug('IP')'. For IP use the ip address of computer running P+.<br><br>
Press the blue upload button, then press reset on the CN1 board to upload the model.<br><br>
The IP address is only for reset and reboot of the taget board!
]], {Height = 150})
    --gui.add('Edit', 'EditIP', 'IP')
    gui.add('EditIP', 'EditIP', 'IP', 'CN*')
    gui.add('Edit', 'EditPort', 'Port', {Width = 60})
    gui.set('EditIP', 'Text', self.parameter.ip)
    gui.set('EditPort', 'Text', self.parameter.port)
  end,

  apply = function(self)
    self.parameter.ip = gui.get('EditIP', 'Text')
    self.parameter.port = gui.get('EditPort', 'Text')
  end,

  close = function(self)
  end,

  generate = function(self, what)
    if what == 'GENERATOR_REQUIRE' then
      return [[
sys = require 'sys'
w5500 = require 'w5500'
require 'ShowSubSystem'
token = {set = function() end, get = function() end}
      ]]
    end
    if what == 'GENERATOR_MAIN' then
      return [[
do
  local pin = require 'pin'
  --pin.config('A7', 'LOW')
  while true do
    local tick, ellapsedS = sys.isTicked()
    if tick then
      sim.timeS = sim.timeS + ellapsedS
      if not nextS then
        nextS = sim.timeS
      end
      if sim.timeS >= nextS then
        --pin.set('A7', true)
        block.step()
        collectgarbage()
        --pin.set('A7', false)
        sim.step = sim.step + 1
        sim.stepT0 = sim.stepT0 + 1
        nextS = nextS + sim.stepRateS
      end
    end
    w5500.serve()
  end
end
      ]]
    end
  end,

  inject = function(self, files)
    local sys = require 'sys'
    local socket = require 'socket'
    local token = require 'token'
    --sys.debug('Injector start')
    local manualReset = true
    if self.parameter.ip:len() > 7 then
      local tcp = socket.tcp()
      tcp:settimeout(3)
      local server = tcp:connect(self.parameter.ip, self.parameter.port)
      if server then
        injector.addLabel('<b>Connect to debug server at ' .. self.parameter.ip .. ':' .. self.parameter.port .. ' and trigger upload process...</b>')
        --server:send("RESET\n");
        tcp:send("RESTART\n");
        tcp:close()
        manualReset = false
      else
        injector.addLabel('No respone from debug server at ' .. self.parameter.ip .. ':' .. self.parameter.port .. '. So wait for manual board reset.')
      end
    end

    local server = socket.bind('*', 8172)
    injector.assert(server, 'Can\'t create socket with port ' .. self.parameter.port .. '. Already in use?')
    if manualReset then
      injector.addLabel('<FONT size="10"><FONT color="#000080"><b>Press reset on the CN1 board to start upload process</b></FONT></FONT>')
    end
    local pb1 = injector.addProgressBar('Waiting', #files, true)
    server:settimeout(0.1)
    local client, err
    repeat
      client, err = server:accept()
    until client
    server:settimeout(5) -- If CN1 is in JTAG debugging mode it's need
    client:settimeout(5) --   a little more time...
    injector.addLabel('Accepted connection from ' .. client:getpeername())
    local bytes = 0
    --for i = 1, #files do
    --  sys.debug(files[i].host)
    --end
    local fl = injector.addFileList('Uploading')
    local fileCount = 0
    for i = 1, #files do

      if i > 1 then
        sys.sleep(0.05) -- Time for close and open the files on the target
      end
      injector.setProgressBar(pb1, i)
      local file = io.open(files[i].host, "r")
      assert(file)
      local lines = file:read('*a'):gsub('^#!.-\n', '\n')
      file:close()
      local hash = tostring(injector.hash(lines))
      if (token.get('.upload:' .. files[i].host) ~= hash) then
        injector.addFile(fl, files[i].remote)
        local response, text
        for retry = 1, 2 do        
          client:send("UPLOAD " .. tostring(#lines) .. " " .. files[i].remote .. "\n")
          client:send(lines)
          response, text = client:receive()
          if response then
            break
          end
          injector.addLabel('Retry ' .. retry)
          
          
          
          sys.sleep(0.5) -- CN1 Mobdebug timout 2 * 150ms
        end
        injector.assert(response, text)
        local _, _, status, text = string.find(response, "^(%d+)%s+(.*)")
        --sys.debug(status, text)
        injector.assert(status == '200', text)
        bytes = bytes + #lines
        fileCount = fileCount + 1
        token.set('.upload:' .. files[i].host, hash)
      end

    end
    injector.addLabel('Upload succesfull: ' .. bytes .. ' bytes in ' .. fileCount .. ' files')
    for i = 1, #files do
      local startFile = 'startup.lua'
      if files[i].remote == startFile then
        injector.addLabel('Start file is <i>' .. startFile .. '</i>')
        local file = io.open(files[i].host, "r")
        injector.assert(file, 'Can\'t open file <i>' .. files[i].host .. '</i>')
        local lines = file:read('*a'):gsub('^#!.-\n', '\n')
        file:close()
        client:send("LOAD " .. tostring(#lines) .. " " .. files[i].remote .. "\n")
        client:send(lines)
        server:settimeout(5.0)
        local response = client:receive()
        injector.addLabel('Program was started <i>' .. response  .. '</i>')
        client:send("RUN\n")
        break
      end
    end
    injector.delayedClose()
  end,
}









