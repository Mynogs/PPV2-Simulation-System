--**************************************************************************$
--* Copyright (C) 2013-2018 Ing. Buero Riesberg - All Rights Reserved
--* Unauthorized copy, print, modify or use of this file, via any medium is
--* strictly prohibited. Proprietary and confidential.
--* Written by Andre Riesberg <andre@riesberg-net.de>
--***************************************************************************/

-- 15.09.2017 08:31:00 AR V1.0a
-- 23.12.2017 10:45:58 AR V1.0b Add redirect

--[[
Redirect uses
  socat EXEC:"/home/tf/pPlus/CN /home/tf/pPlus/run/startup.lua",stderr TCP:192.168.1.9:13539
--]]

target = {
  name = 'Tinkerforge RED brick via TFP',

  parameter = {
    uid = 'aaaaaa',
    directory = '/home/tf/pPlus/run',
    start = true,
    redirect = true,
    redirectIP = '192.168.1.9'
  },

  init = function(self)
    sys = require 'sys'
    token = require 'token'
    tinkerForge = require 'tinkerForge'

    -- See https://www.tinkerforge.com/de/doc/Software/Bricks/RED_Brick_TCPIP.html#red-brick-tcpip-api
    create_session = 1
    expire_session_unchecked = 3
    release_object_unchecked = 6
    allocate_string = 7
    set_string_chunk = 10
    allocate_list = 12
    append_to_list = 15
    open_file = 17
    write_file_unchecked = 24
    create_directory = 37
    spawn_process = 39
    
    --redBrick, sessionId, nullFileId = nil, nil, nil
    
    function check(result, text)
      --print('result ', result)
      injector.assert(result == 0, 'Error ' .. result .. ' ' .. (text or ''))
    end

    function expireSession()
      redBrick:io(expire_session_unchecked, "u2", sessionId, false)
      sessionId = nil
    end

    function createSession()
      local result = nil
      result, sessionId = redBrick:io(create_session, "u4", 60, "u1u2")
      check(result, 'createSession')
      assert(sessionId and sessionId > 0)
      --print('sessionId', sessionId)
    end

    function releaseObject(o)
      redBrick:io(release_object_unchecked, "u2u2", o, sessionId, false)
    end

    function allocateString(s)
      --print('allocateString', s)
      local result, stringId = redBrick:io(allocate_string, "u4s58u2", #s, s, sessionId, "u1u2")
      check(result, 'allocateString')
      s = s:sub(58 + 1)
      local offset = 58
      while s:len() > 0 do
        --print('allocateString2', s)
        local result = redBrick:io(set_string_chunk, "u2u4s58", stringId, offset, s, "u1u2")
        check(result, 'allocateString')
        s = s:sub(58 + 1)
        offset = offset + 58
      end
      return stringId
    end

    function allocateList(l)
      --print('allocateList', #l)
      local result, listId = redBrick:io(allocate_list, "u2u2", #l, sessionId, "u1u2")
      check(result, 'allocateList')
      for i = 1, #l do
        --print('allocateList2', i, l[i])
        local stringId = allocateString(l[i])
        local result = redBrick:io(append_to_list, "u2u2", listId, stringId, "u1")
        check(result, 'allocateList')
      end
      return listId
    end

    function openNullFile()
      local nullStringId = allocateString('/dev/null')
      local _, nullFileId = redBrick:io(open_file, "u2u4u2u4u4u2", nullStringId, 3, 0, 0, 0, sessionId, "u1u2")
      releaseObject(nullStringId)
      return nullFileId
    end

    function killCNTask()
      --print('killCNTask')
      local executableStringId = allocateString('killall')
      local argumentsListId = allocateList{'CN'}
      local environmentListId = allocateList{}
      local workingDirectoryStringId = allocateString(self.parameter.directory)
      local result = redBrick:io(spawn_process, "u2u2u2u2u4u4u2u2u2u2", executableStringId, argumentsListId, environmentListId, workingDirectoryStringId, 1000, 1000, nullFileId, nullFileId, nullFileId, sessionId, "u1u2")
      --check(result, 'killCNTask')
      releaseObject(executableStringId)
      releaseObject(argumentsListId)
      releaseObject(environmentListId)
      releaseObject(workingDirectoryStringId)
    end

    function startCNTask()
      --print('startCNTask')
      local executableStringId = allocateString('/home/tf/pPlus/CN')
      local argumentsListId = allocateList{sel.parameter.directory .. '/startup.lua'}
      local environmentListId = allocateList{}
      local workingDirectoryStringId = allocateString(self.parameter.directory)
      local result = redBrick:io(spawn_process, "u2u2u2u2u4u4u2u2u2u2", executableStringId, argumentsListId, environmentListId, workingDirectoryStringId, 1000, 1000, nullFileId, nullFileId, nullFileId, sessionId, "u1u2")
      check(result, 'startCNTask')
      releaseObject(executableStringId)
      releaseObject(argumentsListId)
      releaseObject(environmentListId)
      releaseObject(workingDirectoryStringId)
    end

    function startCNTaskWithRedirect()
      --print('startCNTaskWithRedirect')
      local executableStringId = allocateString('socat')
      local argumentsListId = allocateList{
        'EXEC:"/home/tf/pPlus/CN /home/tf/pPlus/run/startup.lua",stderr',
        'TCP:' .. self.parameter.redirectIP .. ':13539'
      }
      local environmentListId = allocateList{}
      local workingDirectoryStringId = allocateString(self.parameter.directory)
      local result = redBrick:io(spawn_process, "u2u2u2u2u4u4u2u2u2u2", executableStringId, argumentsListId, environmentListId, workingDirectoryStringId, 1000, 1000, nullFileId, nullFileId, nullFileId, sessionId, "u1u2")
      check(result, 'startCNTask')
      releaseObject(executableStringId)
      releaseObject(argumentsListId)
      releaseObject(environmentListId)
      releaseObject(workingDirectoryStringId)
    end

    function copyFile(from, to)
      local file = io.open(from, "r")
      assert(file)
      local lines = file:read('*a'):gsub('^#!.-\n', '\n')
      file:close()
      --print('####', to)
      local toStringId = allocateString(to)
      -- open file, write only, user all
      local result, toFileId = redBrick:io(open_file, "u2u4u2u4u4u2", toStringId, 2 | 16 | 32 | 64 | 512, 420, 1000, 1000, sessionId, "u1u2")
      --print('------>', toFileId)
      check(result, 'open file')
      local bytes = lines:len()
      while lines:len() > 0 do
        local part = lines:sub(1, 61)
        redBrick:io(write_file_unchecked, "u2s61u1", toFileId, part, part:len(), false)
        lines = lines:sub(61 + 1)
      end
      releaseObject(toFileId)
      releaseObject(toStringId)
      return bytes
    end

  end,

  open = function(self)
    gui.add('HTMLInfo', 'Info', self.name, [[
<b>Run P+ model on the RED brick</b><br><br>
Install first all files from the '\Resources\Remote\Tinkerforge\.*RED Brick.zip' in the RED brick folder '/home/tf/pPlus'.<br>
Change the flags from the CN file to make it executable (774).<br><br>
Note: Keep in mind the RED brick must 'see' the other bricks and bricklets!<br>
So use always UID's with ip address like '127.0.0.1/trS' or '192.168.1.34/Yds'.
]], {Height = 130})
    gui.add('HTMLLabel', 'Label1', '<b>Connection to RED Brick</b>')
    gui.add('Edit', 'EditUID', 'RED Brick UID')
    gui.add('Button', 'ButtonUID', "Select UID")
    gui.add('Line')
    gui.add('HTMLLabel', 'Label2', '<b>Remote location</b>')
    gui.add('Edit', 'EditDirectory', 'Target directory', {Width = 200})
    gui.add('CheckBox', 'CheckBoxStart', 'Start after upload', {Width = 200})
    gui.add('Line')
    gui.add('HTMLLabel', 'Label3', '<b>Redirect output</b>')
    gui.add('CheckBox', 'CheckBoxRedirect', 'Redirect output (stdout, stderr)', {Width = 200})
    gui.add('Edit', 'EditThisIP', 'Redirect to IP (this)')
    gui.set('EditUID', 'Text', self.parameter.uid)
    gui.set('EditDirectory', self.parameter.directory)
    gui.set('CheckBoxStart', 'Checked', self.parameter.start)
    gui.set('CheckBoxRedirect', 'Checked', self.parameter.redirect)
    gui.set('EditThisIP', 'Text', self.parameter.redirectIP)
    gui.setEventHandler(
      self,
      'ButtonUID',
      {
        Click = function(self)
          local uid = require('tinkerForge').selectDialog('RED Brick', 'brick')
          if uid then
            gui.set('EditUID', 'Text', uid)
            self.parameter.uid = uid
          end
        end,
      }
    )
  end,

  apply = function(self)
    self.parameter.uid = gui.get('EditUID', 'Text')
    self.parameter.directory = gui.get('EditDirectory', 'Text')
    self.parameter.start = gui.get('CheckBoxStart', 'Checked')
    self.parameter.redirect = gui.get('CheckBoxRedirect', 'Checked')
    self.parameter.redirectIP = gui.get('EditThisIP', 'Text')
  end,

  close = function(self)
  end,

  generate = function(self, what)
    if what == 'GENERATOR_HEADER' then
      return [[
package.path = package.path .. ';/home/tf/pPlus/?.lua;/home/tf/pPlus/?'
      ]]
    end
    if what == 'GENERATOR_REQUIRE' then
      return [[
token = {set = function() end, get = function() end}
      ]]
    end
    if what == 'GENERATOR_MAIN' then
      return [[
do
  sys.isTicked()
  while true do
    local tick, ellapsedS = sys.isTicked()
    if tick then
      sim.timeS = sim.timeS + ellapsedS
      if not nextS then
        nextS = sim.timeS
      end
      if sim.timeS >= nextS then
        block.step()
        sim.step = sim.step + 1
        sim.stepT0 = sim.stepT0 + 1
        nextS = nextS + sim.stepRateS
        collectgarbage()
      end
    end
  end
end
      ]]
    end
  end,

  inject = function(self, files, xml)
    sys.debug('Injector start')
    redBrick = tinkerForge.new('RED Brick', self.parameter.uid, 2, 0, 3)
    injector.assert(redBrick, 'Can\t connect to RED brick')
    injector.addLabel('<b>Connect to RED Brick <font color = "#008000">' .. self.parameter.uid .. '</font></b>')
    createSession()
    nullFileId = openNullFile()

    injector.addLabel('Stopping CN task(s)')
    killCNTask()

    -- Create base directory
    do
      --print(self.parameter.directory)
      local fileNameId = allocateString(self.parameter.directory)
      local result = redBrick:io(create_directory, "u2u4u2u4u4", fileNameId, 1, 448, 1000, 1000, "u1")
      check(result)
    end

    -- Create all directorys
    do
      local remoteDirectorys = {}
      for i = 1, #files do
        local remotePath = self.parameter.directory .. '/' .. files[i].remote
        local remoteDirectory = remotePath:match("(.*/)")
        remoteDirectorys[#remoteDirectorys + 1] = remoteDirectory
      end
      local pb1 = injector.addProgressBar('Directorys', #remoteDirectorys, true)
      local fl = injector.addFileList('Make directory')
      table.sort(remoteDirectorys)
      for i, remoteDirectory in ipairs(remoteDirectorys) do
        injector.setProgressBar(pb1, i)
        injector.addFile(fl, remoteDirectory)
        local fileNameId = allocateString(remoteDirectory)
        local result = redBrick:io(create_directory, "u2u4u2u4u4", fileNameId, 1, 448, 1000, 1000, "u1")
        check(result)
      end
    end

    -- Copy all files
    do
      local pb1 = injector.addProgressBar('Upload files', #files, true)
      local fl = injector.addFileList('Uploading')
      local bytes = 0
      for i = 1, #files do
        injector.setProgressBar(pb1, i)
        injector.addFile(fl, files[i].remote)
        bytes = bytes + copyFile(files[i].host, self.parameter.directory .. '/' .. files[i].remote)
      end
      injector.addLabel('Upload succesfull: ' .. bytes .. ' bytes in ' .. #files .. ' files')
    end

    if self.parameter.start then
      if self.parameter.redirect then
        injector.addLabel('Start CN task with redirection to ' .. self.parameter.redirectIP)
        startCNTaskWithRedirect()
      else
        injector.addLabel('Start CN task')
        startCNTask()
      end
    end
    expireSession()
  end,
  
  stop = function(self)
    redBrick = tinkerForge.new('RED Brick', self.parameter.uid, 2, 0, 3)
    injector.assert(redBrick, 'Can\t connect to RED brick')
    injector.addLabel('<b>Connect to RED Brick <font color = "#008000">' .. self.parameter.uid .. '</font></b>')
    createSession()
    nullFileId = openNullFile()
    injector.addLabel('Stopping CN task(s)')
    killCNTask()
    expireSession()
  end
}









