
--**************************************************************************$
--* Copyright (C) 2013-2018 Ing. Buero Riesberg - All Rights Reserved
--* Unauthorized copy, print, modify or use of this file, via any medium is
--* strictly prohibited. Proprietary and confidential.
--* Written by Andre Riesberg <andre@riesberg-net.de>
--***************************************************************************/

target = {
  name = 'Standalone Lua on Windows CLI',

  parameter = {
    directory = nil,
  },

  init = function(self)
    --print('init')
    sys = require 'sys'
    token = require 'token'
  end,

  open = function(self)
    --print('open')
    local imageDirectory = token.get('.resourcesPath') .. [[\Remote\WindowsCLI\.Image]]
    if not self.parameter.directory then
      self.parameter.directory = imageDirectory
    end
    gui.add('HTMLInfo', 'Info', self.name, [[
<b>Use standard prebuild Lua53.exe to run the model</b><br><br>

Copy the '.image' folder to a different place and adjust the path!<br><br>
The '.image' folder is here:<br>
<a href="]] .. imageDirectory .. [[">]] .. imageDirectory .. [[</a><br><br>
You can use the default target directory but the folder will polluted with simulation files!
]], {Height = 150})
    gui.add('Edit', 'EditDirectory', 'Target directory', {Width = 500})
    gui.set('EditDirectory', self.parameter.directory)
  end,

  apply = function(self)
    self.parameter.directory = gui.get('EditDirectory', 'Text')
  end,

  close = function(self)
  end,

  generate = function(self, what)
    if what == 'GENERATOR_HEADER' then
      local directory = self.parameter.directory:gsub('\\', '\\\\')
      return [[
package.path = package.path .. ';]] .. directory .. [[\\?.lua;]] .. directory .. [[\\?'
      ]]
    end
    if what == 'GENERATOR_REQUIRE' then
      return [[
token = {set = function() end, get = function() end}
      ]]
    end
    if what == 'GENERATOR_MAIN' then
      local Source = ''
      if injector.projectHasFlags('RunInRealtime') then
        source = [[
do
  while sim.endTimeS <= 0 or sim.timeS <= sim.endTimeS do
    sim.timeS = os.clock()
    if not nextS then
      nextS = sim.timeS
    end
    if sim.timeS >= nextS then
      block.step()
      sim.step = sim.step + 1
      sim.stepT0 = sim.stepT0 + 1
      nextS = nextS + sim.stepRateS
      collectgarbage()
    end
  end
end
        ]]
      else
        source = [[
do
  while sim.endTimeS <= 0 or sim.timeS <= sim.endTimeS do
    block.step()
    sim.step = sim.step + 1
    sim.stepT0 = sim.stepT0 + 1
    nextS = nextS + sim.stepRateS
    collectgarbage()
  end
end
        ]]
      end
      return source
    end
  end,

  inject = function(self, files)
    --for k, v in pairs(injector) do print(k, v) end
    sys.debug('Injector start')
    injector.needPPVersion(2, 1, 'd')
    local function copy(from, to)
      local dir = to:match('(.*)[/\\]')
      --print(dir)
      --print(from)
      --print(to)
      --print()
      injector.createDirectory(dir)
      local f1 = assert(io.open(from, 'rb'))
      local f2 = assert(io.open(to, 'wb'))
      f2:write(f1:read('*a'))
    end
    local function windowsPath(s)
      return s:gsub('/', '\\')
    end

    --injector.addLabel('Stopping Lua53.exe')
    --os.execute('Taskkill /IM Lua53.exe /F')

    do
      local f = assert(io.open(windowsPath(self.parameter.directory .. '/start.bat'), 'w'))
      f:write([[lua53.exe startup.lua]])
      f:close()
    end

    -- Copy all files
    do
      local pb1 = injector.addProgressBar('Upload files', #files, true)
      local fl = injector.addFileList('Uploading')
      local bytes = 0
      for i = 1, #files do
        injector.setProgressBar(pb1, i)
        injector.addFile(fl, files[i].remote)
        copy(windowsPath(files[i].host), windowsPath(self.parameter.directory .. '/' .. files[i].remote))
      end
      injector.addLabel('Copy succesfull: ' .. #files .. ' files')
      injector.addLabel('Start Lau35.exe')
      --print(windowsPath(self.parameter.directory .. '/start.bat'))
      --os.execute('start "' .. windowsPath(self.parameter.directory .. '/Lua53.exe" startup.lua'))
    end

  end,

--  stop = function(self)
--  end
}









