-- Config Wizard
-- AR

local cw = {}

cw.version = 100

cw.init = function(self, items)
  self.items = items
end

cw.doInit = function(self)  
  

end

cw.doOpen = function(self)  
  

end

cw.doApply = function(self)  
  

end

cw.doClose = function(self)  
  

end
  
  for i = 1, #items do
    local item = items[i]
    if 





return cw

