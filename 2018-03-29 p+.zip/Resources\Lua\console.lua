-- console.lua

-- Copyright (C) 2013-2016 Ing. Buero Riesberg - All Rights Reserved
-- Unauthorized copy, print, modify or use of this file, via any medium is
-- strictly prohibited. Proprietary and confidential.
-- Written by Andre Riesberg <andre@riesberg-net.de>

print('Loading console.lua')
vector = require 'vector'
matrix = require 'matrix'
complex = require 'complex'
