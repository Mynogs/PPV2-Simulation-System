-----------------------------------------------------------------------------
-- TinkerForge adapter
-- André Riesberg P+ project
-- 20170729 First version
-----------------------------------------------------------------------------

local tinkerForge = {}

local sequenceNumber = 0

--
-- generate a new sequence number in the range of 1 to 15
--
local nextSequenceNumber = function()
  sequenceNumber = sequenceNumber + 1
  if sequenceNumber > 15 then
    sequenceNumber = 1
  end
end

--
-- BASE58 decoder
--
local base58Decode = function(s)
  if not s or s:len() > 13 then
    return -1
  end
  local t = '123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ'
  function find(x)
    for i = 1, #t do
      if t:byte(i, i) == x then
        return i
      end
    end
    return -1
  end
  local r = 0
  for i = 1, #s do
    local v = find(s:byte(i, i))
    if v < 0 then
      return -1
    end
    r = r * 58 + (v - 1)
  end
  return r
end

-- 
-- Make a packet 
-- 
local makePacket = function(uid, functionID, responseExpected, payLoad)
  nextSequenceNumber()
  local v = base58Decode(uid)
  if v < 0 then
    return 
  end
  local s = string.char(
    v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF,  -- UID as base58
    8 + #payLoad,                                                   -- Length of the complete packet (header and payload) in bytes
    functionID,                                                     -- Function ID
    (sequenceNumber << 4) | (responseExpected and 8 or 0),          -- SSSSR000 S:sequnece number from 1..15, R:response expected 
    0                                                               -- Future use
  )
  return s .. payLoad
end

-- Input output function
-- Call samples:
--   bricklet:io(1, false, false)                              Send command 1
--   bricklet:io(2, 'u1u1', u1, u2, false)                     Send command 2 and two unsigned bytes 
--   d1, d2 ,d3 = bricklet:io(1, false, 'd2d2d2')              Send command 1 and receive three signed words
--   d1, d2 ,d3 = bricklet:io(1, 'u1u1', u1, u2, 'd2d2d2')     Send command 1 and two unsigned bytes and receive three signed words
--
tinkerForge.io = function(self, functionID, sendFormat, ...)
  local recvFormat = arg[#arg]
  --print(self.client, self.ip, self.uid, self.io)
  --print(sendFormat, recvFormat)
  
  local payLoad = ''
  if sendFormat then
    for i = 1, 48 do
      local _, p, t, l = string.find(sendFormat, '(%l)(%d*)')
      if not t then
        break
      end
      l = l or 1
      sendFormat = sendFormat:sub(p + 1)
      --print('#', t, l, arg[i])
      if t == 'b' then
        local v = arg[i] and 1 or 0
        for i = 1, l do
          payLoad = payLoad .. string.char(v & 0xFF)
        v = v >> 8
        end
      elseif t == 'u' then
        local v = (type(arg[i]) == 'boolean' and (arg[i] and 1 or 0) or arg[i]) & 0xFFFFFFFF
        for i = 1, l do
          payLoad = payLoad .. string.char(v & 0xFF)
        v = v >> 8
        end
      elseif t == 'd' then
        local v = type(arg[i]) == 'boolean' and (arg[i] and 1 or 0) or arg[i]
        for i = 1, l do
          payLoad = payLoad .. string.char(v & 0xFF)
        v = v >> 8
        end
      elseif t == 's' then
        --
      end
    end
  end  
  --print('-->', payLoad:byte(1, #payLoad))
  do
    local packet = makePacket(self.uid, functionID, recvFormat, payLoad)
    if not packet then 
      return 
    end
    self.client:send(packet) 
  end
  if recvFormat then
    local header = self.client:receive(8)
    print('header', header)
    if header then
      print('header', header:byte(1, #header))
      if header:byte(8, 8) & 0xC0 ~= 0 then
        return 
      end
      local l = header:byte(5, 5)
      print('length', l)
      if l > 0 then
        local payLoad = self.client:receive(l - 8)
        print(payLoad)
        if not payLoad then
          return
        end
        print('<-----------', payLoad:byte(1, #payLoad))
        local r = 1
        local result = {}
        local function shift(b, i)
          return b << (i * 8 - 8)
        end
        for i = 1, 48 do
          local _, p, t, l = string.find(recvFormat, '(%l)(%d*)')
          if not t then
            return unpack(result)
          end
          l = l or 1
          recvFormat = recvFormat:sub(p + 1)
          if t == 'b' then
            local v = 0
            for i = 1, l do
              v = v | shift(payLoad:byte(r, r), i)
              r = r + 1
            end
            result[#result + 1] = v ~= 0
          elseif t == 'u' then
            local v = 0
            for i = 1, l do
              v = v | shift(payLoad:byte(r, r), i)
              r = r + 1
            end
            result[#result + 1] = v
          elseif t == 'd' then
            local v, m, n = 0, -1 
            for i = 1, l do
              n = payLoad:byte(r, r)
              v = v | shift(n, i)
              m = m << 8
              r = r + 1
            end
            if n & 0x80 ~= 0 then
              v = v | m
            end
            result[#result + 1] = v
          elseif t == 's' then
            --
          end
        end
        return unpack(result)
      end
    end
  end
end

tinkerForge.new = function(name, uid, apiVersionMajor, apiVersionMinor, apiVersionRelease)
  local _, p, ip = string.find(uid, '(%d+%.%d+%.%d+%.%d+)/')
  local uid = p and uid:sub(p + 1) or uid
  local socket = require 'socket'
  local client = socket.connect(ip or '127.0.0.1', 4223)
  if not client then 
    return nil, [[Can't connect to ]] .. ip
  end
  client:settimeout(10)
  client:setoption('keepalive' , true)
  client:setoption('tcp-nodelay' , true)
  
  return {socket = socket, client = client, ip = ip, uid = uid, io = tinkerForge.io}
end

return tinkerForge