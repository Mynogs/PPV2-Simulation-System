--[[
 *  p+ Lua library
 *  Copyright (C) Andre Riesberg
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not,
 *  write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
--]]
-----------------------------------------------------------------------------
-- tiny redis module
-- Author: Andre Riesberg
-- 30.11.2019 V1.0a First version
-- 25.04.2020 V1.0b Results compatible to common use REDIS Lua lib
-----------------------------------------------------------------------------

redis = {

  tinyredis = 1.01,

  mt = {},

  init = function(self, tcp)
    --print("tinyredis.init", self.tinyredis, self.request, self.response, tcp.send, tcp.receive)
    assert(self.tinyredis and self.request and self.response and tcp.send and tcp.receive)
    self.tcp = tcp
    self._io = function(self, name, ...)
      local ok, result = pcall(self.request, self, name, ...)
      if ok then
        ok, result = pcall(self.response, self)
      end
      if ok then
        return result
      end
      return nil, 'TinyREDIS error on ' .. name
    end
    self.mt.__index = function(self, name)
      return function(self, ...)
        return self:_io(name, ...)
      end
    end
    setmetatable(self, self.mt)
    return self
  end,

  request = function(self, ...)
    assert(self.tinyredis)
    local tcp = self.tcp
    local args = {...}
    local n = #args
    tcp:send(string.format('*%d\r\n', n))
    for i = 1, n do
      local s = tostring(args[i])
      tcp:send(string.format('$%d\r\n%s\r\n', s:len(), s))
    end
  end,

  response = function(self)
    local tcp = self.tcp
    local status, message = assert(tcp:receive(1))
    if status == '+' then
      local s = assert(tcp:receive())
      return s
    elseif status == '-' then
      return assert(tcp:receive())
    elseif status == ':' then
      local i = tonumber(assert(tcp:receive()))
      assert(i, 'Missing integer in :')
      return i
    elseif status == '$' then
      local l = tonumber(assert(tcp:receive()))
      assert(l, 'Missing length in bulk string')
      if l < 0 then
        return
      end
      local s = assert(tcp:receive(l))
      assert(tcp:receive())
      return s
    elseif status == '*' then
      local l = tonumber(assert(tcp:receive()))
      assert(l, 'Missing length in array')
      local array = {}
      for i = 1, l do
        local ok, result = self:response()
        if not ok then
          error(result .. ' at index ' .. i)
        end
        array[i] = result
      end
      return array
    end
    error('Invalid redis status')
  end,

}

return redis
